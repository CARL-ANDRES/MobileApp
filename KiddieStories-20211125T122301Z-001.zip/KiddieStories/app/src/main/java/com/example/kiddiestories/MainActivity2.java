package com.example.kiddiestories;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity2 extends AppCompatActivity {
    TextView tvWelcome;

    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        tvWelcome=findViewById(R.id.tvWelcome);

        firebaseAuth=FirebaseAuth.getInstance();
        firebaseUser=firebaseAuth.getCurrentUser();

        String email = firebaseUser.getEmail();

        tvWelcome.setText("WELCOME" +"\n"+email);

    }
    public void stories(View view){
        Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
        startActivity(intent);
    }
    public void favorites(View view){
        Intent intent = new Intent(MainActivity2.this, MainActivity14.class);
        startActivity(intent);
    }

    public void quiz(View view) {
        Intent intent = new Intent(MainActivity2.this, QuizActivity.class);
        startActivity(intent);
    }
}
