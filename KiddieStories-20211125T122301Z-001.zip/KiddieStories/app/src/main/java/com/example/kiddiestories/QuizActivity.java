package com.example.kiddiestories;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.kiddiestories.classes.Quiz;
import com.example.kiddiestories.classes.Score;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class QuizActivity extends AppCompatActivity {
    private static ArrayList<Quiz> quizArrayList = new ArrayList<>();
    ImageView ivTest;
    TextView tvQuestion;
    int position = 0;
    TextView tvNumber;
    Button btn1, btn2;
    TextView tvAnswer, tvChosen, tvScore;
    int mScore = 0;
    ProgressDialog progressDialog;
    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    SimpleDateFormat simpleDateFormat;
    DatabaseReference databaseReference;
    String email;
    Date date;
    Score score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        ivTest = findViewById(R.id.ivTest);
        tvQuestion = findViewById(R.id.tvQuestion);
        tvNumber = findViewById(R.id.tvNumber);
        tvAnswer = findViewById(R.id.tvAnswer);
        tvChosen = findViewById(R.id.tvChosen);
        tvScore = findViewById(R.id.tvScore);

        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Getting data");
        progressDialog.setMessage("Loading please wait...");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        email = firebaseUser.getEmail();
        databaseReference = FirebaseDatabase.getInstance().getReference("scores");

        addQuiz();

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                showQuiz(position);
            }
        }, 2000);
    }

    private void showQuiz(int position) {
        int img = quizArrayList.get(position).getTestImage();

        if (img != 0) {
            Glide.with(getApplicationContext()).load(img).into(ivTest);
            ivTest.setVisibility(View.VISIBLE);
        } else {
            ivTest.setVisibility(View.GONE);
        }

        tvQuestion.setText(quizArrayList.get(position).getQuestion());
        tvNumber.setText("QUESTION " + (position + 1) + "/" + quizArrayList.size());
        btn1.setText(quizArrayList.get(position).getC1());
        btn2.setText(quizArrayList.get(position).getC2());
        tvAnswer.setText(quizArrayList.get(position).getAnswer());
        tvChosen.setText("");
        tvScore.setText(String.valueOf(mScore));
        progressDialog.dismiss();
    }

    public void btn1(View view) {
        String c1 = btn1.getText().toString();
        tvChosen.setText(c1);

        btn2.setBackgroundColor(btn2.getContext().getResources().getColor(R.color.purple_500));
        btn1.setBackgroundColor(btn1.getContext().getResources().getColor(R.color.purple_200));
    }

    public void btn2(View view) {
        String c2 = btn2.getText().toString();

        tvChosen.setText(c2);

        btn2.setBackgroundColor(btn2.getContext().getResources().getColor(R.color.purple_200));
        btn1.setBackgroundColor(btn1.getContext().getResources().getColor(R.color.purple_500));
    }

    public void addQuiz() {

        quizArrayList.clear();

        Quiz q1 = new Quiz(0, "How Many Letters Are There In The Alphabet?", "26", "22", "26");
        Quiz q2 = new Quiz(0, "What letter comes after E", "F", "G", "F");
        Quiz q3 = new Quiz(0, "What letter comes after H", "I", "J", "I");
        Quiz q4 = new Quiz(R.drawable.apple, "Choose the letter that goes with the picture", "B", "A", "A");
        Quiz q5 = new Quiz(R.drawable.owl, "Choose the letter that goes with the picture", "W", "O", "O");
        Quiz q6 = new Quiz(R.drawable.hat, "Choose the letter that goes with the picture", "I", "H", "H");
        Quiz q61 = new Quiz(R.drawable.igloo, "Choose the letter that goes with the picture", "I", "H", "I");
        Quiz q7 = new Quiz(0, "What is the first letter of the alphabet?", "Z", "A", "A");
        Quiz q8 = new Quiz(0, "What is the last letter of the alphabet?", "Z", "A", "Z");
        Quiz q9 = new Quiz(0, "Match the letter C?", "C", "A", "C");
        Quiz q10 = new Quiz(0, "Match the letter Y?", "C", "Y", "Y");
        Quiz q11 = new Quiz(0, "The story of THE ANT AND THE DOVE. Was the dove was quick to fly away to safety?", "Yes", "No", "Yes");
        Quiz q12 = new Quiz(0, "The story of THE LONELY PRINCES. How many young princess are lived in the Kingdom of Glora ?", "3", "4", "3");
        Quiz q13 = new Quiz(0, "How many dwarfs are there in the story of SNOW WHITE ?", "8", "7", "7");
        Quiz q14 = new Quiz(0, "The story of THE FRIENDSHIP OF A LION AND A MOUSE. Did the Lion helped the mouse get down and prevented the mouse from hurting himself ?", "No", "Yes", "Yes");


        quizArrayList.add(q1);
        quizArrayList.add(q2);
        quizArrayList.add(q3);
        quizArrayList.add(q4);
        quizArrayList.add(q5);
        quizArrayList.add(q6);
        quizArrayList.add(q61);
        quizArrayList.add(q7);
        quizArrayList.add(q8);
        quizArrayList.add(q9);
        quizArrayList.add(q10);
        quizArrayList.add(q11);
        quizArrayList.add(q12);
        quizArrayList.add(q13);
        quizArrayList.add(q14);
    }

    public void submit(View view) {
        if (tvChosen.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please select an answer...", Toast.LENGTH_SHORT).show();
        } else {
            if (tvChosen.getText().toString().equalsIgnoreCase(tvAnswer.getText().toString())) {
                mScore++;
            }
            if (position + 1 >= quizArrayList.size()) {
                AlertDialog.Builder alert = new AlertDialog.Builder(this);
                alert.setMessage("Your score is " + String.valueOf(mScore) + "/" + quizArrayList.size());
                alert.setCancelable(false);
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy ");
                        date = new Date();

                        String id = databaseReference.push().getKey();

                        score = new Score(email, simpleDateFormat.format(date), mScore + "/" + quizArrayList.size());

                        databaseReference.child(id).setValue(score);
                        finish();
                    }
                });
                alert.show();
            } else {
                btn2.setBackgroundColor(btn2.getContext().getResources().getColor(R.color.purple_500));
                btn1.setBackgroundColor(btn1.getContext().getResources().getColor(R.color.purple_500));
                position++;
                showQuiz(position);
            }
        }
    }
}